import { Transaction } from '@onelabs/sui/transactions';

const PACKAGE_ID = "0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff";

const LIMITER_CONFIG = "0xc67391154cc2adb68cbd3f2d4bf4795b67d0eb6b042e68dc2e26b51593233bea";
const YOCT_CAP = "0xf67c96c757abc20279ffd738fb921754084f3b6ef5b9643e4c29e264275d3e33";
const RD_CONFIG = "0xa2f9729cf6dfa4b64dd63162a0efc8f8f01b9393bf7aacaeeb95bbe5c112ae41";
const SAVER_CONFIG = "0xa56a0b697ab5dadc7650c58559360d29e6671de368034611ae74b55d41b64921";
const SROCT_CAP = "0x6eb11b1ce86db0a01252b21e3c8e9402d6f3e0bb7c8154b926f09da5f10e83f7";
const MOCK_VAULT = "0x32f22551866e2bc3ab674d6cdb5ab08350df6c0ae7e9e8855c9b787504df6471"; // OCT  YOCT 
const CLOCK = "0x6";
const SROCT_MINTER = "0xa400d2b70bb34b3fbbb340e36edea13ad72df00532a459741046723f1e33ae65";
const SAVER_YOCT_VAULT = "0x08552ef7d945befccde7c07a100e97d28bd5c5cc63f34e51e8c763cb87fd9257";
const KEEPER_CAP = "0x0c3cca2a40ebc7afb4e6cef742d93b06fe406edeb5ed003cfe795ad7d691338a";
const ADAPTER_CONFIG = "0x9aed760b1af3b634d742fda92d2c59a1cf57c08a7cedb555932217d825d31650";
const UT = "0xd7f52795f1b97617564c422c90b8f0766077547b6f3e11bb7d769f64d8dc7810";
const LIQUIDATE_LIMITER = "0xae3b7f93c0ab1193573615fbda9eb20654acfc3c62c82640c1e6fe67d16d7dce";
const RD_VAULT = "0x9c5681c908cec3ae0b5dc31b8a51271c5ff4e39d2b6d0b95fa5d126f20c29b93";
const USER_INFO = "0xe37c2990ed51b448fc99754ec27a05492011c5a9c43ad6b55c4a5e1f4d38b3cf";
const RD_ACCOUNT = "0x887c351fb6c9151a503b59b2ae3c08f2cea91557ff7806c3dc0e8618df057b3e";

function toU64(val: string | number | bigint): bigint {
    return BigInt(val);
}

export function initUserInfo(
) : Transaction {
    const moduleName = "saver";
    const functionName = "init_user_info";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();

    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType2, coinType3],
        arguments: [
           tx.object(SROCT_MINTER),
        ],
    });

    return tx;
}

export function buildDepositTx(
    amount: string | number | bigint,
    user_info: string
): Transaction {
    const moduleName = "saver";
    const functionName = "deposit_underlying";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    
    const tx = new Transaction();
    const amount_to_deposit = amount;
    let coin_input = tx.splitCoins(
        tx.gas,
        [tx.pure.u64(amount_to_deposit)]
    );

    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType2, coinType3],
        arguments: [
           tx.object(UT),
           tx.object(ADAPTER_CONFIG),
           coin_input,
           tx.object(user_info),
           tx.object(SAVER_YOCT_VAULT),
           tx.object(SROCT_MINTER),
           tx.object(CLOCK),
           tx.object(MOCK_VAULT)
        ],
    });

    return tx;
}

export function borrow(
    amount: string,
    user_info: string,
    recipient: string
): Transaction {
    const moduleName = "mock_adapter";
    const functionName = "mint";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();

    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType2, coinType3],
        arguments: [
            tx.object(UT),
            tx.object(ADAPTER_CONFIG),
            tx.object(user_info),
            tx.object(SROCT_MINTER),
            tx.object(CLOCK),
            tx.pure.u64(amount),
            tx.pure.address(recipient),
            tx.object(MOCK_VAULT)
        ],
    });

    return tx;
}

export function repay_with_debt_token(
    user_info: string
): Transaction {
    const moduleName = "mock_adapter";
    const functionName = "burn";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();

    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType2, coinType3],
        arguments: [
            tx.object(ADAPTER_CONFIG),
            tx.object(user_info),
            tx.object("0x2b11de8c0ca9df6d195a9d92c495083595f204667947b2ec99e8f5930a5a542e"),
            tx.object(SROCT_MINTER),
            tx.object(CLOCK),
        ],
    });

    return tx;
}

export function repay_with_oct(
    amount : string,
    user_info: string
): Transaction {
    const moduleName = "mock_adapter";
    const functionName = "repay";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();
    const amount_to_deposit = amount;
    let coin_input = tx.splitCoins(
        tx.gas,
        [tx.pure.u64(amount_to_deposit)]
    );

    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType2, coinType3],
        arguments: [
            tx.object(ADAPTER_CONFIG),
            tx.object(UT),
            coin_input,
            tx.object(user_info),
            tx.object(SROCT_MINTER),
            tx.object(CLOCK),
            tx.object(RD_CONFIG),
            tx.object(RD_VAULT),
            tx.object(MOCK_VAULT)
        ],
    });

    return tx;
}

export function redeem(
    amount : string,
    recipient: string
): Transaction {
    const moduleName = "redeem_pool";
    const functionName = "redeem";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();

    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType3],
        arguments: [
            tx.object(RD_CONFIG),
            tx.object(RD_VAULT),
            tx.object("0x80e5e81883ecc53a832661ee58313f13a2bb8272981fde8ccd6bf58c1f78df99"),
            tx.object(SROCT_MINTER),
            tx.pure.address(recipient),
        ],
    });
    
    return tx;
}

export function liquidate(
    amount_share_to_liquidate: string,
    user_info: string
): Transaction {
    const moduleName = "mock_adapter";
    const functionName = "liquidate"
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();
    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType2, coinType3],
        arguments: [
            tx.object(ADAPTER_CONFIG),
            tx.object(UT),
            tx.object(user_info),
            tx.object(SROCT_MINTER),
            tx.object(SAVER_YOCT_VAULT),
            tx.object(CLOCK),
            tx.pure.u128(amount_share_to_liquidate),
            tx.object(LIQUIDATE_LIMITER),
            tx.pure.u128(0),
            tx.object(MOCK_VAULT),
            tx.object(RD_CONFIG),
            tx.object(RD_VAULT)
        ],
    });
    
    return tx;
}

export function harvest(
    keeper_cap_id: string,
    minimum_amount_out: string
) {
    const moduleName = "mock_adapter";
    const functionName = "harvest"
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();
    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType2, coinType3],
        arguments: [
            tx.object(ADAPTER_CONFIG),
            tx.object(UT),
            tx.object(keeper_cap_id),
            tx.object(SROCT_MINTER),
            tx.object(SAVER_YOCT_VAULT),
            tx.object(CLOCK),
            tx.pure.u128(minimum_amount_out),
            tx.object(RD_CONFIG),
            tx.object(RD_VAULT),
            tx.object(MOCK_VAULT),
        ],
    });
    
    return tx;
}

export function withdraw(
    user_info: string,
    recipient: string,
    share_to_withdraw: string
) {
    const moduleName = "mock_adapter";
    const functionName = "withdraw_underlying";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();
    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType2, coinType3],
        arguments: [
            tx.object(UT),
            tx.object(ADAPTER_CONFIG),
            tx.object(SAVER_YOCT_VAULT),
            tx.object(user_info),
            tx.object(SROCT_MINTER),
            tx.object(CLOCK),
            tx.pure.u64(share_to_withdraw),
            tx.pure.address(recipient),
            tx.object(MOCK_VAULT)
        ],
    });
    
    return tx;
}

export function snap() { //only admin
    const moduleName = "mock_adapter";
    const functionName = "snap";
    const coinType1 = "0x2::oct::OCT";
    const coinType2 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::yoct::YOCT';
    const coinType3 = '0x397c94d79dd96411c770a4d1893a6b23a8487d34db6998cdec772fde475118ff::sroct::SROCT';
    const tx = new Transaction();
    tx.moveCall({
        target: `${PACKAGE_ID}::${moduleName}::${functionName}`,
        typeArguments: [coinType1, coinType2, coinType3],
        arguments: [
            tx.object(UT),
            tx.object(ADAPTER_CONFIG),
            tx.object(SROCT_MINTER),
            tx.object(MOCK_VAULT)
        ],
    });
    
    return tx;
}