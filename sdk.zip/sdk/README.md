# SDK Transactions (`sdk/tx.ts`)

This module provides helper functions to build Sui transactions for the Saver Protocol integration.

## Functions

### `initUserInfo()`
Initializes a new `UserInfo` object for the caller. This is required before interacting with the protocol (depositing, borrowing, etc.).
- **Returns**: `Transaction` object to be signed and executed.

### `buildDepositTx(amount, user_info)`
Deposits underlying tokens (e.g., OCT) into the protocol.
- **Parameters**:
  - `amount`: Amount of tokens to deposit (string, number, or bigint).
  - `user_info`: The object ID of the user's `UserInfo`.
- **Returns**: `Transaction` object.

### `borrow(amount, user_info, recipient)`
Borrows underlying tokens against collateral.
- **Parameters**:
  - `amount`: Amount to borrow.
  - `user_info`: The user's `UserInfo` object ID.
  - `recipient`: Address to receive the borrowed tokens.
- **Returns**: `Transaction` object.

### `repay_with_debt_token(user_info)`
Repays debt using the debt token (e.g., SROCT) directly.
- **Parameters**:
  - `user_info`: The user's `UserInfo` object ID.
- **Returns**: `Transaction` object.

### `repay_with_oct(amount, user_info)`
Repays debt using the underlying token (e.g., OCT).
- **Parameters**:
  - `amount`: Amount of underlying token to use for repayment.
  - `user_info`: The user's `UserInfo` object ID.
- **Returns**: `Transaction` object.

### `redeem(amount, recipient)`
Redeems underlying tokens from the Redeem Pool using share tokens.
- **Parameters**:
  - `amount`: Amount of shares to redeem.
  - `recipient`: Address to receive the redeemed tokens.
- **Returns**: `Transaction` object.

### `withdraw(user_info, recipient, share_to_withdraw)`
Withdraws underlying tokens directly from the vault/adapter (if allowed).
- **Parameters**:
  - `user_info`: The user's `UserInfo` object ID.
  - `recipient`: Address to receive the tokens.
  - `share_to_withdraw`: Amount of shares to burn/withdraw.
- **Returns**: `Transaction` object.

### `liquidate(amount_share_to_liquidate, user_info)`
Liquidates a user's position that is under-collateralized.
- **Parameters**:
  - `amount_share_to_liquidate`: Amount of debt shares to liquidate.
  - `user_info`: The `UserInfo` object ID of the user being liquidated.
- **Returns**: `Transaction` object.

### `harvest(keeper_cap_id, minimum_amount_out)`
Harvests yield from the strategy.
- **Parameters**:
  - `keeper_cap_id`: Object ID of the Keeper Capability.
  - `minimum_amount_out`: Minimum amount of yield expected.
- **Returns**: `Transaction` object.

### `snap()`
Admin function to take a snapshot of the system state.
- **Returns**: `Transaction` object.

## Constants used
The file uses several hardcoded constants for the Testnet environment (Package ID, Config IDs, etc.). Ensure these match your target environment or modify the file to allow configuration injection.

# SDK Read Functions (`sdk/read.ts`)

This module provides helper functions to read state from the on-chain Move objects.

## Functions

### `getUserInfoId(client, address, packageId)`
Retrieves the object ID of the `UserInfo` object associated with a given address.
- **Parameters**:
    - `client`: `SuiClient` instance.
    - `address`: The user's address.
    - `packageId`: The package ID of the protocol.
- **Returns**: `Promise<string | undefined>`. Returns `undefined` if not found.

### `getUserInfoDebt(client, address, packageId)`
Retrieves the current debt of the user.
- **Parameters**: Same as `getUserInfoId`.
- **Returns**: `Promise<string | undefined>`.

### `getUserInfoProfit(client, address, packageId)`
Retrieves the current profit of the user.
- **Parameters**: Same as `getUserInfoId`.
- **Returns**: `Promise<string | undefined>`.

### `getUserInfoSharesBalance(client, address, packageId)`
Retrieves the user's balance of shares (deposited tokens).
- **Parameters**: Same as `getUserInfoId`.
- **Returns**: `Promise<string | undefined>`.

### `getRedeemPoolBalance(redeem_pool_vault_id, client)`
Retrieves the current balance of underlying tokens in the Redeem Pool vault.
- **Parameters**:
    - `redeem_pool_vault_id`: Object ID of the redeem pool vault.
    - `client`: `SuiClient` instance.
- **Returns**: `Promise<string | undefined>`.

