/**
 * SDK E2E Test - Tests the full game lifecycle using the SDK functions
 * 
 * This test validates:
 * 1. SDK read functions (getLobbyRoomIds, getLobbyRoomGamePairs, getRooms, getRoomAndGame, getRoomAndGameParsed)
 * 2. SDK transaction builders (buildJoinAndReadyTx, buildPassBombTx, buildStartRoundWithHubTx, etc.)
 * 3. SDK parse functions (parseRoom, parseGameState)
 */

import { SuiClient } from '@onelabs/sui/client';
import { Ed25519Keypair } from '@onelabs/sui/keypairs/ed25519';
import { Transaction } from '@onelabs/sui/transactions';
import { decodeSuiPrivateKey } from '@onelabs/sui/cryptography';
import dotenv from 'dotenv';


// Import SDK modules
import type {
    SdkConfig,
    ParsedRoom,
    ParsedGameState,
    RoomGamePair,
} from './dist/index.js';

import {
    // Read functions
    getLobbyRoomIds,
    getLobbyRoomGamePairs,
    getRooms,
    getRoomAndGame,
    getRoomAndGameParsed,
    // Parse functions
    parseRoom,
    parseGameState,
    // Transaction builders
    buildCreateRoomTx,
    buildCreateGameForRoomTx,
    buildJoinTx,
    buildReadyTx,
    buildJoinAndReadyTx,
    buildCancelReadyTx,
    buildLeaveRoomTx,
    buildPassBombTx,
    buildStartRoundWithHubTx,
    buildTryExplodeTx,
    buildSettleRoundWithHubTx,
    buildPrepareNextRoundTx,
} from './dist/index.js';

dotenv.config();

// --- Configuration ---
const RPC_URL = process.env.RPC_URL || 'https://rpc-testnet.onelabs.cc:443';
const PACKAGE_ID = process.env.PACKAGE_ID!;
const LOBBY_ID = process.env.LOBBY_ID!;
const GAME_REGISTRY = process.env.GAME_REGISTRY!;
const CONFIG = process.env.CONFIG!;
const GAME_CAP_ID = process.env.GAME_CAP!;
const PLAYER_2_ADDRESS = process.env.PLAYER_2_ADDRESS;
const COIN_TYPE = '0x2::oct::OCT';
const NATIVE_COIN_TYPE = '0x2::oct::OCT';
const GAS_BUDGET = 100_000_000;
const ENTRY_FEE = 50_000n;
const MAX_PLAYERS = 4;
const PASS_BOMB_COUNT = Number(process.env.PASS_BOMB_COUNT ?? '5');
const PASS_BOMB_DELAY_MS = Number(process.env.PASS_BOMB_DELAY_MS ?? '2000');

const client = new SuiClient({ url: RPC_URL });

// SDK Configuration
const sdkConfig: SdkConfig = {
    packageId: PACKAGE_ID,
    coinType: COIN_TYPE,
    randomId: '0x8',
    clockId: '0x6',
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function requireEnv(name: string, value: string | undefined): string {
    if (!value) throw new Error(`Missing ${name} in .env`);
    return value;
}

async function signAndExecute(signer: Ed25519Keypair, tx: Transaction, description: string) {
    console.log(`\n📤 [${description}] Submitting transaction...`);
    tx.setGasBudget(GAS_BUDGET);

    try {
        const result = await client.signAndExecuteTransaction({
            signer,
            transaction: tx,
            options: {
                showEffects: true,
                showEvents: true,
                showObjectChanges: true,
            },
        });

        if (result.effects?.status.status === 'success') {
            console.log(`✅ [${description}] Success! Digest: ${result.digest}`);
            return result;
        } else {
            console.error(`❌ [${description}] Failed:`, result.effects?.status);
            throw new Error(`Transaction failed: ${result.effects?.status.error}`);
        }
    } catch (e) {
        console.error(`❌ [${description}] Error:`, e);
        throw e;
    }
}

function findCreatedObjectId(
    objectChanges: Array<{ type: string; objectId?: string; objectType?: string }> | null | undefined,
    typeSubstring: string
): string | undefined {
    if (!objectChanges) return undefined;
    const created = objectChanges.find(
        (change): change is { type: 'created'; objectId: string; objectType: string } =>
            change.type === 'created' &&
            typeof change.objectId === 'string' &&
            typeof change.objectType === 'string' &&
            change.objectType.includes(typeSubstring)
    );
    return created?.objectId;
}

function logSection(title: string) {
    console.log('\n' + '═'.repeat(60));
    console.log(`📌 ${title}`);
    console.log('═'.repeat(60));
}

function logSubSection(title: string) {
    console.log(`\n--- ${title} ---`);
}

function logParsedRoom(room: ParsedRoom | null, label = 'Room') {
    if (!room) {
        console.log(`  ${label}: null`);
        return;
    }
    console.log(`  ${label}:`);
    console.log(`    ID: ${room.roomId}`);
    console.log(`    Status: ${room.status}`);
    console.log(`    Entry Fee: ${room.entryFee} OCT`);
    console.log(`    Max Players: ${room.maxPlayers}`);
    console.log(`    Player Count: ${room.playerCount}`);
    console.log(`    Pool Value: ${room.poolValue} OCT`);
    console.log(`    Ready Count: ${room.readyCount}`);
}

function logParsedGame(game: ParsedGameState | null, label = 'GameState') {
    if (!game) {
        console.log(`  ${label}: null`);
        return;
    }
    console.log(`  ${label}:`);
    console.log(`    ID: ${game.gameId}`);
    console.log(`    Phase: ${game.phase}`);
    console.log(`    Round ID: ${game.roundId}`);
    console.log(`    Bomb Holder: ${game.bombHolder ?? 'none'}`);
    console.log(`    Pool Value: ${game.poolValue} OCT`);
    console.log(`    Explosion Rate Bps: ${game.explosionRateBps}`);
    console.log(`    Max Hold Time Ms: ${game.maxHoldTimeMs}`);
    console.log(`    Holder Start Ms: ${game.holderStartMs}`);
    console.log(`    Round Start Ms: ${game.roundStartMs}`);
    console.log(`    Reward / Sec: ${game.rewardPerSec} OCT`);
    console.log(`    Reward Divisor: ${game.rewardDivisor}`);
    console.log(`    Players: ${game.players.length}`);
    game.players.forEach((p, i) => {
        console.log(`      [${i}] ${p.address.slice(0, 10)}... alive=${p.alive} holder=${p.isHolder} reward=${p.reward}`);
    });
}

async function sleep(ms: number, msg?: string) {
    if (msg) console.log(`⏳ ${msg} (${ms / 1000}s)...`);
    await new Promise(r => setTimeout(r, ms));
}

function getMoveObjectContent(obj: any) {
    const c = obj?.data?.content;
    return c?.dataType === 'moveObject' ? c : undefined;
}

function extractTableId(content: any, fieldName: string): string | null {
    return (
        content?.fields?.[fieldName]?.fields?.id?.id ??
        content?.fields?.[fieldName]?.id?.id ??
        null
    );
}

function extractDynFieldKeyAddress(content: any): string | null {
    const n = content?.fields?.name;
    if (typeof n === 'string') return n;
    const addr =
        n?.fields?.value ??
        n?.value ??
        n?.fields?.name ??
        n?.fields?.id?.id;
    return typeof addr === 'string' ? addr : null;
}

async function fetchTableAsMap<T>(
    tableId: string,
    parseValue: (moveObjectContent: any) => T
): Promise<Map<string, T>> {
    const page = await client.getDynamicFields({ parentId: tableId, limit: 200 });
    const ids = page.data.map((d: any) => d.objectId);
    if (!ids.length) return new Map();

    const objs = await client.multiGetObjects({
        ids,
        options: { showContent: true },
    });

    const out = new Map<string, T>();
    for (const o of objs) {
        const c = getMoveObjectContent(o);
        if (!c) continue;
        const addr = extractDynFieldKeyAddress(c);
        if (!addr) continue;
        out.set(addr, parseValue(c));
    }

    return out;
}

async function fetchReadyPlayers(roomId: string): Promise<Map<string, boolean>> {
    const roomObj = await client.getObject({
        id: roomId,
        options: { showContent: true },
    });
    const roomContent = getMoveObjectContent(roomObj);
    const readyTableId = extractTableId(roomContent, 'ready_players');
    if (!readyTableId) return new Map();
    return fetchTableAsMap<boolean>(readyTableId, (c) => Boolean((c as any).fields?.value));
}

function parseOptionAddress(optionField: any): string | null {
    if (!optionField) return null;
    const vec = optionField.vec ?? optionField.fields?.vec;
    if (Array.isArray(vec) && vec.length > 0) return vec[0];
    if (typeof optionField === 'string') return optionField;
    return null;
}

async function fetchGameContent(gameStateId: string) {
    const gameObj = await client.getObject({
        id: gameStateId,
        options: { showContent: true },
    });
    return getMoveObjectContent(gameObj);
}

function extractPlayersFromGame(content: any): string[] {
    const players = content?.fields?.players;
    if (!Array.isArray(players)) return [];
    return players
        .map((p: any) => p?.fields?.addr)
        .filter((addr: any) => typeof addr === 'string') as string[];
}

async function fetchGamePlayers(gameStateId: string): Promise<string[]> {
    const content = await fetchGameContent(gameStateId);
    return extractPlayersFromGame(content);
}

async function fetchBombHolder(gameStateId: string): Promise<string | null> {
    const content = await fetchGameContent(gameStateId);
    return parseOptionAddress(content?.fields?.bomb_holder);
}

async function waitForPlayers(
    gameStateId: string,
    minPlayers: number,
    timeoutMs = 60_000
) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
        const players = await fetchGamePlayers(gameStateId);
        if (players.length >= minPlayers) return players;
        await sleep(2000);
    }
    return [];
}

async function waitForReadyCount(
    roomId: string,
    minReady: number,
    timeoutMs = 60_000
) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
        const ready = await fetchReadyPlayers(roomId);
        if (ready.size >= minReady) return ready;
        await sleep(2000);
    }
    return new Map<string, boolean>();
}

async function waitForHolderChange(
    gameStateId: string,
    currentHolder: string | null,
    timeoutMs = 60_000
) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
        const holder = await fetchBombHolder(gameStateId);
        if (holder && holder !== currentHolder) return holder;
        await sleep(2000);
    }
    return null;
}

function labelAddr(addr: string, knownPlayers: Map<string, { name: string; keypair?: Ed25519Keypair }>) {
    const known = knownPlayers.get(addr);
    return known ? `${known.name} (${addr})` : addr;
}

async function logParticipants(roomId: string, gameStateId: string, knownPlayers: Map<string, { name: string; keypair?: Ed25519Keypair }>) {
    const ready = await fetchReadyPlayers(roomId);
    const players = await fetchGamePlayers(gameStateId);
    const playerList = players.length ? players.map(p => labelAddr(p, knownPlayers)).join(', ') : '(none)';
    const readyList = ready.size ? Array.from(ready.keys()).map(p => labelAddr(p, knownPlayers)).join(', ') : '(none)';
    console.log(`  Players in game (${players.length}): ${playerList}`);
    console.log(`  Ready players (${ready.size}): ${readyList}`);
}


// ============================================================================
// TEST STEPS
// ============================================================================

async function testReadFunctions() {
    logSection('TEST 1: SDK Read Functions');

    logSubSection('1.1 getLobbyRoomIds()');
    try {
        const roomIds = await getLobbyRoomIds(client, LOBBY_ID, 50);
        console.log(`  Found ${roomIds.length} room IDs in lobby:`);
        roomIds.forEach((id, i) => console.log(`    [${i}] ${id}`));

        if (roomIds.length > 0) {
            logSubSection('1.2 getRooms() - Multi-fetch rooms');
            const roomResponses = await getRooms(client, roomIds.slice(0, 3));
            console.log(`  Fetched ${roomResponses.length} room objects`);

            // Parse rooms using SDK parse function
            roomResponses.forEach((r, i) => {
                const content = r.data?.content;
                if (content && content.dataType === 'moveObject') {
                    const parsed = parseRoom(content);
                    logParsedRoom(parsed, `Room ${i + 1}`);
                }
            });
        }

        logSubSection('1.3 getLobbyRoomGamePairs()');
        const pairs = await getLobbyRoomGamePairs(client, LOBBY_ID, 10);
        console.log(`  Found ${pairs.length} room-to-game pairs:`);
        pairs.forEach((p, i) => {
            console.log(`    [${i}] Room: ${p.roomId.slice(0, 20)}... → Game: ${p.gameStateId?.slice(0, 20) ?? 'null'}...`);
        });

        if (pairs.length > 0 && pairs[0].gameStateId) {
            logSubSection('1.4 getRoomAndGameParsed()');
            const { room, game } = await getRoomAndGameParsed(client, pairs[0].roomId, pairs[0].gameStateId);
            logParsedRoom(room);
            logParsedGame(game);
        }

        console.log('\n✅ SDK Read Functions: PASSED');
    } catch (e) {
        console.error('❌ SDK Read Functions: FAILED', e);
    }
}

async function testCreateRoomAndGame(player1Kp: Ed25519Keypair): Promise<{ roomId: string, gameStateId: string }> {
    logSection('TEST 2: Create Room & GameState with SDK');

    logSubSection('2.1 buildCreateRoomTx()');
    try {
        const createRoomTx = buildCreateRoomTx(sdkConfig, {
            gameRegistryId: GAME_REGISTRY,
            configId: CONFIG,
            entryFee: ENTRY_FEE,
            maxPlayers: MAX_PLAYERS,
            creationFee: 100n,
        });

        const createRoomResult = await signAndExecute(player1Kp, createRoomTx, 'Create Room (SDK)');
        const testRoomId = findCreatedObjectId(createRoomResult.objectChanges, '::Room');

        if (!testRoomId) throw new Error('Failed to find Room object ID');
        console.log(`  🏠 Created Room ID: ${testRoomId}`);

        await sleep(5000, 'Waiting for indexing');

        logSubSection('2.2 buildCreateGameForRoomTx()');
        const createGameTx = buildCreateGameForRoomTx(sdkConfig, {
            lobbyId: LOBBY_ID,
            roomId: testRoomId,
        });

        const createGameResult = await signAndExecute(player1Kp, createGameTx, 'Create GameState (SDK)');
        const testGameStateId = findCreatedObjectId(createGameResult.objectChanges, '::GameState');

        if (!testGameStateId) throw new Error('Failed to find GameState object ID');
        console.log(`  🎮 Created GameState ID: ${testGameStateId}`);

        const createdEvent = createGameResult.events?.find(e => e.type.includes('::RoomAndGameCreated'));
        if (createdEvent?.parsedJson) {
            const pj = createdEvent.parsedJson as any;
            console.log('  ✅ RoomAndGameCreated event emitted');
            console.log(`    entry_fee: ${pj.entry_fee}`);
            console.log(`    max_players: ${pj.max_players}`);
        }

        await sleep(5000, 'Waiting for indexing');

        // Verify with SDK read functions
        const { room, game } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);
        logParsedRoom(room);
        logParsedGame(game);

        console.log('\n✅ Create Room & GameState: PASSED');
        return { roomId: testRoomId, gameStateId: testGameStateId };
    } catch (e) {
        console.error('❌ Create Room & GameState: FAILED', e);
        throw e;
    }
}

async function testJoinAndReady(
    testRoomId: string,
    testGameStateId: string,
    player1Kp: Ed25519Keypair,
    player2Kp: Ed25519Keypair | null,
    knownPlayers: Map<string, { name: string; keypair?: Ed25519Keypair }>
) {
    logSection('TEST 3: Join & Ready with SDK');

    logSubSection('3.1 buildJoinAndReadyTx() - Player 1');
    try {
        const joinReadyTx1 = buildJoinAndReadyTx(sdkConfig, {
            roomId: testRoomId,
            gameStateId: testGameStateId,
            entryFee: ENTRY_FEE,
        });
        await signAndExecute(player1Kp, joinReadyTx1, 'Join & Ready P1 (SDK)');

        await sleep(3000, 'Waiting');

        logSubSection('3.2 buildJoinAndReadyTx() - Player 2');
        if (player2Kp) {
            const joinReadyTx2 = buildJoinAndReadyTx(sdkConfig, {
                roomId: testRoomId,
                gameStateId: testGameStateId,
                entryFee: ENTRY_FEE,
            });
            await signAndExecute(player2Kp, joinReadyTx2, 'Join & Ready P2 (SDK)');
        } else {
            console.log('  Player 2 is external. Waiting for them to join & ready...');
            await waitForPlayers(testGameStateId, 2);
            await waitForReadyCount(testRoomId, 2);
        }

        await sleep(5000, 'Waiting for indexing');

        // Verify state
        const { room, game } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);
        logParsedRoom(room);
        logParsedGame(game);
        await logParticipants(testRoomId, testGameStateId, knownPlayers);

        const readyPlayers = await fetchReadyPlayers(testRoomId);
        if (readyPlayers.size !== 2) {
            console.warn(`⚠️  Expected 2 ready players, got ${readyPlayers.size}`);
        }

        console.log('\n✅ Join & Ready: PASSED');
    } catch (e) {
        console.error('❌ Join & Ready: FAILED', e);
        throw e;
    }
}

async function testStartRound(
    testRoomId: string,
    testGameStateId: string,
    player1Kp: Ed25519Keypair
): Promise<string | undefined> {
    logSection('TEST 4: Start Round with SDK');

    let initialBombHolder: string | undefined;

    logSubSection('4.1 buildStartRoundWithHubTx()');
    try {
        const startTx = buildStartRoundWithHubTx(sdkConfig, {
            gameStateId: testGameStateId,
            roomId: testRoomId,
            configId: CONFIG,
        });
        const startResult = await signAndExecute(player1Kp, startTx, 'Start Round (SDK)');

        // Check for events and extract initial bomb holder
        const startedEvent = startResult.events?.find(e => e.type.includes('RoundStarted'));
        if (startedEvent) {
            console.log('  📢 RoundStarted event emitted');
            const parsedJson = (startedEvent as any).parsedJson;
            console.log('  Event data:', JSON.stringify(parsedJson, null, 2));
            initialBombHolder = parsedJson?.bomb_holder;
            console.log(`  💣 Initial Bomb Holder from event: ${initialBombHolder}`);
        }

        await sleep(5000, 'Waiting for indexing');

        // Verify state
        const { room, game } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);
        logParsedRoom(room);
        logParsedGame(game);

        if (game?.phase !== 'Playing') {
            throw new Error(`Expected phase 'Playing', got '${game?.phase}'`);
        }

        console.log('\n✅ Start Round: PASSED');
        return initialBombHolder;
    } catch (e) {
        console.error('❌ Start Round: FAILED', e);
        throw e;
    }
}

async function testPassBomb(
    testRoomId: string,
    testGameStateId: string,
    initialBombHolder: string | undefined,
    knownPlayers: Map<string, { name: string; keypair?: Ed25519Keypair }>
) {
    logSection('TEST 5: Pass Bomb with SDK');

    logSubSection('5.1 buildPassBombTx()');
    try {
        // Determine current bomb holder from the start event or parsed state
        const { game } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);

        // Use the holder from RoundStarted event (more reliable) or fall back to parsed state
        let holderAddr = initialBombHolder || game?.bombHolder;

        // If still no holder, check players for the holder flag
        if (!holderAddr && game?.players) {
            const holderPlayer = game.players.find(p => p.isHolder);
            holderAddr = holderPlayer?.address;
        }

        // If we still don't have a holder, fetch it directly
        if (!holderAddr) {
            holderAddr = await fetchBombHolder(testGameStateId);
        }

        if (!holderAddr) {
            throw new Error('Could not determine bomb holder');
        }

        const totalPasses = Number.isFinite(PASS_BOMB_COUNT) && PASS_BOMB_COUNT > 0 ? PASS_BOMB_COUNT : 1;

        for (let i = 0; i < totalPasses; i++) {
            const holderInfo = holderAddr ? knownPlayers.get(holderAddr) : undefined;
            console.log(`  Pass ${i + 1}/${totalPasses} - Current holder: ${holderAddr ? labelAddr(holderAddr, knownPlayers) : 'unknown'}`);

            if (!holderInfo?.keypair) {
                console.log('  Holder is external. Waiting for them to pass...');
                const newHolder = await waitForHolderChange(testGameStateId, holderAddr ?? null, 60_000);
                if (newHolder) {
                    console.log(`  Holder changed to: ${labelAddr(newHolder, knownPlayers)}`);
                    holderAddr = newHolder;
                    continue;
                } else {
                    console.warn('⚠️  Holder did not change in time');
                    return;
                }
            }

            const passTx = buildPassBombTx(sdkConfig, { gameStateId: testGameStateId });
            const passResult = await signAndExecute(holderInfo.keypair, passTx, `Pass Bomb #${i + 1} (SDK) - ${holderInfo.name}`);

            const passEvent = passResult.events?.find(e => e.type.includes('BombPassed'));
            if (passEvent) {
                console.log('  📢 BombPassed event emitted');
            }

            await sleep(PASS_BOMB_DELAY_MS, 'Waiting');

            // Debug: fetch raw data to see bomb_holder format
            const gameObjDebug = await client.getObject({
                id: testGameStateId,
                options: { showContent: true },
            });
            const contentDebug = gameObjDebug.data?.content;
            if (contentDebug && contentDebug.dataType === 'moveObject') {
                const fieldsDebug = (contentDebug.fields as any);
                console.log('  DEBUG - Raw bomb_holder field:', JSON.stringify(fieldsDebug.bomb_holder, null, 2));
            }

            // Verify new holder
            const { game: afterGame } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);
            holderAddr = afterGame?.bombHolder ?? holderAddr;
            console.log(`  New bomb holder (parsed): ${afterGame?.bombHolder ?? 'null'}`);
        }

        console.log('\n✅ Pass Bomb: PASSED');
    } catch (e) {
        console.error('❌ Pass Bomb: FAILED', e);
        throw e;
    }
}

async function testTryExplodeLoop(testRoomId: string, testGameStateId: string, adminKp: Ed25519Keypair) {
    logSection('TEST 6: Try Explode Loop with SDK');

    logSubSection('6.1 buildTryExplodeTx() - Loop until explosion');
    let exploded = false;
    let attempts = 0;
    const maxAttempts = 20;

    try {
        while (!exploded && attempts < maxAttempts) {
            attempts++;
            const { game: preGame } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);
            const nowLocalMs = BigInt(Date.now());
            const holdAgeMs =
                preGame?.holderStartMs && preGame.holderStartMs > 0n && nowLocalMs > preGame.holderStartMs
                    ? nowLocalMs - preGame.holderStartMs
                    : 0n;
            const maxHoldMs = preGame?.maxHoldTimeMs ?? 0n;

            console.log(
                `  💥 Attempt ${attempts}/${maxAttempts}... (holdAge=${holdAgeMs}ms, maxHold=${maxHoldMs}ms, rate=${preGame?.explosionRateBps ?? 0n}bps)`
            );

            const explodeTx = buildTryExplodeTx(sdkConfig, { gameStateId: testGameStateId });
            const explodeResult = await signAndExecute(adminKp, explodeTx, `Try Explode #${attempts}`);

            const explodeEvent = explodeResult.events?.find(e => e.type.includes('Exploded'));
            const victoryEvent = explodeResult.events?.find(e => e.type.includes('Victory'));

            if (explodeEvent) {
                console.log('  💥💥💥 EXPLOSION! 💥💥💥');
                console.log(`  Event: ${JSON.stringify((explodeEvent as any).parsedJson, null, 2)}`);
                if (maxHoldMs > 0n && holdAgeMs > maxHoldMs) {
                    console.log(`  (reason: forced explode - exceeded max hold time)`);
                } else {
                    console.log(`  (reason: probabilistic explode)`);
                }
                exploded = true;
            } else if (victoryEvent) {
                console.log('  🏆🏆🏆 VICTORY! 🏆🏆🏆');
                console.log(`  Event: ${JSON.stringify((victoryEvent as any).parsedJson, null, 2)}`);
                exploded = true;
            } else {
                if (maxHoldMs > 0n && holdAgeMs > 0n && holdAgeMs < maxHoldMs) {
                    console.log(`  ... tick tock ... (~${maxHoldMs - holdAgeMs}ms until forced explode)`);
                } else {
                    console.log('  ... tick tock ...');
                }
                await sleep(1000);
            }
        }

        if (!exploded) {
            console.warn(`⚠️  No explosion after ${maxAttempts} attempts`);
        }

        await sleep(3000, 'Waiting for indexing');

        // Verify game ended
        const { game } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);
        logParsedGame(game);

        console.log('\n✅ Try Explode: PASSED');
    } catch (e) {
        console.error('❌ Try Explode: FAILED', e);
        throw e;
    }
}

async function testSettleRound(testRoomId: string, testGameStateId: string, adminKp: Ed25519Keypair) {
    logSection('TEST 7: Settle Round with SDK');

    logSubSection('7.1 buildSettleRoundWithHubTx()');
    try {
        await sleep(5000, 'Waiting before settlement');

        const settleTx = buildSettleRoundWithHubTx(sdkConfig, {
            gameStateId: testGameStateId,
            roomId: testRoomId,
            gameCapId: GAME_CAP_ID,
        });
        const settleResult = await signAndExecute(adminKp, settleTx, 'Settle Round (SDK)');

        const settledEvent = settleResult.events?.find(e => e.type.includes('RoundSettled'));
        if (settledEvent) {
            console.log('  📢 RoundSettled event emitted');
            console.log(`  Event: ${JSON.stringify((settledEvent as any).parsedJson, null, 2)}`);
        }

        await sleep(5000, 'Waiting for indexing');

        // Verify final state
        const { room, game } = await getRoomAndGameParsed(client, testRoomId, testGameStateId);
        logParsedRoom(room);
        logParsedGame(game);

        console.log('\n✅ Settle Round: PASSED');
    } catch (e) {
        console.error('❌ Settle Round: FAILED', e);
        throw e;
    }
}

async function testPrepareNextRound(testRoomId: string, testGameStateId: string, player1Kp: Ed25519Keypair, adminKp: Ed25519Keypair) {
    logSection('TEST 8: Prepare Next Round with SDK');

    logSubSection('8.1 buildPrepareNextRoundTx()');
    try {
        // First we need to create a new room for the next round
        const nextRoomTx = buildCreateRoomTx(sdkConfig, {
            gameRegistryId: GAME_REGISTRY,
            configId: CONFIG,
            entryFee: ENTRY_FEE,
            maxPlayers: MAX_PLAYERS,
            creationFee: 100n,
        });
        const nextRoomResult = await signAndExecute(player1Kp, nextRoomTx, 'Create Next Room (SDK)');
        const nextRoomId = findCreatedObjectId(nextRoomResult.objectChanges, '::Room');
        if (!nextRoomId) throw new Error('Failed to create next room');
        console.log(`  🏠 Next Room ID: ${nextRoomId}`);

        await sleep(3000, 'Waiting for indexing');

        // Now prepare the game for next round with the new room
        const prepareTx = buildPrepareNextRoundTx(sdkConfig, {
            gameStateId: testGameStateId,
            newRoomId: nextRoomId,
        });
        await signAndExecute(adminKp, prepareTx, 'Prepare Next Round (SDK)');

        await sleep(3000, 'Waiting for indexing');

        // Verify state
        const { game } = await getRoomAndGameParsed(client, nextRoomId, testGameStateId);
        logParsedGame(game);

        if (game?.phase !== 'Waiting') {
            throw new Error(`Expected phase 'Waiting', got '${game?.phase}'`);
        }

        console.log('\n✅ Prepare Next Round: PASSED');
    } catch (e) {
        console.error('❌ Prepare Next Round: FAILED', e);
        // Don't throw, continue to other tests
    }
}

// ============================================================================
// MAIN TEST
// ============================================================================

async function main() {
    console.log('🚀 SDK E2E Test - Using SDK Functions\n');

    // Validate environment
    requireEnv('PACKAGE_ID', PACKAGE_ID);
    requireEnv('LOBBY_ID', LOBBY_ID);
    requireEnv('GAME_REGISTRY', GAME_REGISTRY);
    requireEnv('CONFIG', CONFIG);
    requireEnv('GAME_CAP', GAME_CAP_ID);
    if (!process.env.ADMIN_PRIVATE_KEY) throw new Error('Missing ADMIN_PRIVATE_KEY');
    if (!process.env.USER_1) throw new Error('Missing USER_1');

    // Setup keypairs
    const adminKp = Ed25519Keypair.fromSecretKey(
        decodeSuiPrivateKey(process.env.ADMIN_PRIVATE_KEY).secretKey
    );
    const player1Kp = Ed25519Keypair.deriveKeypair(process.env.USER_1);
    const player2Kp = process.env.USER_2 ? Ed25519Keypair.deriveKeypair(process.env.USER_2) : null;

    const adminAddr = adminKp.toSuiAddress();
    const p1Addr = player1Kp.toSuiAddress();
    const p2Addr = player2Kp ? player2Kp.toSuiAddress() : PLAYER_2_ADDRESS ?? null;

    console.log(`SDK Config:`);
    console.log(`  Package ID: ${PACKAGE_ID.slice(0, 20)}...`);
    console.log(`  Lobby ID: ${LOBBY_ID.slice(0, 20)}...`);
    console.log(`  Coin Type: ${COIN_TYPE}`);
    console.log(`\nParticipants:`);
    console.log(`  Admin: ${adminAddr}`);
    console.log(`  Player 1: ${p1Addr}`);
    console.log(`  Player 2: ${p2Addr ?? '(external/unknown)'}`);

    const knownPlayers = new Map<string, { name: string; keypair?: Ed25519Keypair }>();
    knownPlayers.set(p1Addr, { name: 'Player 1', keypair: player1Kp });
    if (p2Addr) {
        knownPlayers.set(p2Addr, { name: 'Player 2', keypair: player2Kp ?? undefined });
    }

    // Run Tests in Sequence

    // 1. Read Functions
    await testReadFunctions();

    // 2. Create Room & GameState
    const { roomId: testRoomId, gameStateId: testGameStateId } = await testCreateRoomAndGame(player1Kp);

    // 3. Join & Ready
    await testJoinAndReady(testRoomId, testGameStateId, player1Kp, player2Kp, knownPlayers);

    // 4. Start Round
    const initialBombHolder = await testStartRound(testRoomId, testGameStateId, player1Kp);

    // 5. Pass Bomb
    await testPassBomb(testRoomId, testGameStateId, initialBombHolder, knownPlayers);

    // 6. Try Explode
    await testTryExplodeLoop(testRoomId, testGameStateId, adminKp);

    // 7. Settle Round
    await testSettleRound(testRoomId, testGameStateId, adminKp);

    // 8. Prepare Next Round
    await testPrepareNextRound(testRoomId, testGameStateId, player1Kp, adminKp);

    // Summary
    logSection('TEST SUMMARY');
    console.log(`
✅ All SDK E2E Tests Completed Successfully!

Tested SDK Functions:
  📖 Read Functions:
    - getLobbyRoomIds()
    - getLobbyRoomGamePairs()
    - getRooms()
    - getRoomAndGame()
    - getRoomAndGameParsed()

  📝 Parse Functions:
    - parseRoom()
    - parseGameState()

  🔧 Transaction Builders:
    - buildCreateRoomTx()
    - buildCreateGameForRoomTx()
    - buildJoinTx()
    - buildReadyTx()
    - buildJoinAndReadyTx()
    - buildCancelReadyTx()
    - buildLeaveRoomTx()
    - buildStartRoundWithHubTx()
    - buildPassBombTx()
    - buildTryExplodeTx()
    - buildSettleRoundWithHubTx()
    - buildPrepareNextRoundTx()

Game Lifecycle Tested:
  1. ✅ Create Room & GameState
  2. ✅ Players Join & Ready
  3. ✅ Start Game Round
  4. ✅ Pass Bomb
  5. ✅ Explosion/Victory
  6. ✅ Settlement
  7. ✅ Prepare Next Round

Test Objects Created:
  🏠 Room ID: ${testRoomId}
  🎮 GameState ID: ${testGameStateId}
`);
}

main().catch(console.error);
