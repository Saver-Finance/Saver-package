export type UserDepositInfoFields = {
  last_accrue_weight: string; 
  shares_balance: string;    
  mint_allowance: string;    
  withdraw_allowance: {
    id: string; 
  };
};


export type UserInfoFields = {
  id: {
    id: string;
  };
  debt: string;       
  profit: string;     
  owner: string;    
  deposited_token: UserDepositInfoFields;
};

export type BalanceFields = {
  value: string; 
};

export type VaultFields = {
  id: {
    id: string; 
  };

  ut_balance: BalanceFields;

  conversion_factor: string; 
};
