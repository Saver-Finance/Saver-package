import type { SuiClient } from '@onelabs/sui/client';
import type { SuiObjectResponse } from '@onelabs/sui/client';
import {UserInfoFields, VaultFields} from './types';

// Helper function to check if a MoveStruct has fields property
function hasFields(fields: any): fields is { [key: string]: any } {
    return fields !== null && typeof fields === 'object' && !Array.isArray(fields);
}

export async function getUserInfoId(
    client: SuiClient,
    address: string, 
    packageId: string
): Promise<string | undefined> {
    try {
        const objects = await client.getOwnedObjects({
            owner: address,
            
            filter: {
                StructType: `${packageId}::userinfo::UserInfo`
            },
            options: {
                showContent: true,
            },
        });

        const userInfoObject = objects.data[0];
        
        if (!userInfoObject) {
            console.warn("⚠️ Không tìm thấy UserInfo cho địa chỉ này.");
            return undefined;
        }

        return userInfoObject.data?.objectId;
    } catch (error) {
        console.error("❌ Lỗi khi lấy userInfoId:", error);
        return undefined;
    }
}

export async function getUserInfoDebt(
    client: SuiClient,
    address: string, 
    packageId: string
): Promise<string | undefined> {
    const user_info_id = await getUserInfoId(client, address, packageId);
    if(user_info_id == undefined) {
        return undefined;
    }
    const user_info = await client.getObject({
        id: user_info_id!,
        options: {
            showType: true,
            showOwner: true,
            showContent: true,
        },
    });
    let fields = getMoveFields<UserInfoFields>(user_info);
    return fields.debt;
}

export async function getUserInfoProfit(
    client: SuiClient,
    address: string, 
    packageId: string
): Promise<string | undefined> {
    const user_info_id = await getUserInfoId(client, address, packageId);
    if(user_info_id == undefined) {
        return undefined;
    }
    const user_info = await client.getObject({
        id: user_info_id!,
        options: {
            showType: true,
            showOwner: true,
            showContent: true,
        },
    });
    let fields = getMoveFields<UserInfoFields>(user_info);
    return fields.profit;
}

export async function getUserInfoSharesBalance(
    client: SuiClient,
    address: string, 
    packageId: string
): Promise<string | undefined> {
    const user_info_id = await getUserInfoId(client, address, packageId);
    if(user_info_id == undefined) {
        return undefined;
    }
    const user_info = await client.getObject({
        id: user_info_id!,
        options: {
            showType: true,
            showOwner: true,
            showContent: true,
        },
    });
    let fields = getMoveFields<UserInfoFields>(user_info);
    return fields.deposited_token.shares_balance;
}

export async function getRedeemPoolBalance(
    redeem_pool_vault_id: string,
    client: SuiClient,
): Promise<string | undefined> {
    const redeem_pool_vault = await client.getObject({
        id: redeem_pool_vault_id,
        options: {
            showType: true,
            showOwner: true,
            showContent: true,
        },
    });
    if(!redeem_pool_vault) {
        return undefined;
    }
    let fields = getMoveFields<VaultFields>(redeem_pool_vault);
    return fields.ut_balance.value;
}

function getMoveFields<T>(
  obj: SuiObjectResponse
): T {
  const content = obj.data?.content;

  if (!content || content.dataType !== "moveObject") {
    throw new Error("Not a Move object");
  }

  return content.fields as T;
}

